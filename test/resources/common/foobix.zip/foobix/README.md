# Foobix

This is foobix package

## Introduction

Foobix is a wonderfull package that helps user to print 'foobix' in the terminal

## Usage
```
./foobix
```

## Known bugs

Sadly, foobix prints 'foobax'. We're working to fix this as soon as possible


