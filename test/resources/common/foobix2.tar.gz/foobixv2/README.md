# Foobix

This is foobix package V2.0

## Introduction

Foobix is a wonderfull package that helps user to print 'foobix' in the terminal

## Usage
```
./foobix
```

## Known bugs

None


